"""
SelfDB Python Client Library.
"""

from .client import SelfDB

__version__ = "0.1.0"

__all__ = [
    "SelfDB",
    "__version__"
]